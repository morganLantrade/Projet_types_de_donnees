(* Compilation functions *)

open Lang
open Instrs

(* ************************************************************ *)
(* **** Compilation of expressions / statements            **** *)
(* ************************************************************ *)




let indexOf (var: instr_var ) varTab = match var with
    IVarNamed(name) -> snd(List.find (fun(x) -> fst(x)=name) varTab)
    |IVarNum(num) -> num;;


(* indexOF*)

let rec gen_expr (var: instr_var ) (exp : 'a expr) varTab = match exp with
     Const(_,BoolV(c)) -> let value = if c then 1 else 0 in 
                            [Store(IIndex(indexOf var varTab),ConstSE(value))]
    |Const(_,IntV(c)) -> [Store(IIndex(indexOf var varTab),ConstSE(c))]
    |VarE(_,name) -> let i1,i2 = (indexOf var varTab) ,(indexOf (IVarNamed(name)) varTab) in
                [Store(IIndex(i1),VarSE(IIndex(i2)))]
    |BinOp (_, b, e1,e2) -> let i = indexOf var varTab  in 
            let ex1,ex2 = gen_expr (IVarNum(List.length varTab+1)) e1 varTab, gen_expr (IVarNum(List.length varTab + 2)) e2 varTab in 
                ex1@ex2@[Store(IIndex(i),BinOpSE(b,IIndex(i+1),IIndex(i+2)))]
    |IfThenElse (_,cond, e1,e2) -> 
        let i = indexOf var varTab  in 
            let ex1,ex2 = gen_expr (IVarNum(List.length varTab+1))  e1 varTab, gen_expr (IVarNum(List.length varTab+2))  e2 varTab in 
                let j1 = List.length ex1  in 
                    [Branch(IIndex(i),RelJump(1),RelJump(j1))]@ex1@ex2;;




let rec gen_stmt (var: instr_var ) (stmt: 'a stmt) varTab = match stmt with 
    Skip -> [Goto(RelJump(1))]
   | Assign(_,name,exp) -> 
        let e = gen_expr (IVarNum(List.length varTab+1)) exp varTab in 
             e@[Store(IIndex(indexOf var varTab),VarSE(IIndex(indexOf (IVarNamed(name)) varTab)))]
  | Seq(stmt1,stmt2) -> let s1,s2 = (gen_stmt var stmt1 varTab) , (gen_stmt var stmt2 varTab) in 
          s1@s2
  | While(exp,stmt) -> let i = (indexOf var varTab) in 
        let e1 = (gen_expr (IVarNum(i+1)) exp varTab) in 
            let s1=  gen_stmt (IVarNum(i+1)) stmt varTab in 
                let l1,l2 = List.length e1,List.length s1 in
                e1@[Branch(IIndex(i),RelJump(1),RelJump(l2))]@s1@[Goto(RelJump(-l2+1))]
  | Cond(exp,stmt1,stmt2) ->
         let i = (indexOf var varTab) in 
            let e1 = (gen_expr (IVarNum(i)) exp varTab) in
                let s1,s2=  gen_stmt (IVarNum(i)) stmt1 varTab , gen_stmt (IVarNum(i)) stmt2 varTab in  
                    let l1= List.length s1 in
                e1@[Branch(IIndex(i),RelJump(1),RelJump(l1))]@s1@s2


  | Return(exp) -> let e1 = (gen_expr var exp varTab) in 
                e1@[Exit(IIndex(indexOf var varTab))];;

let name_of_vardecl (Vardecl (_, vn)) = vn;;

let rec list_vardecl (i : int) (l : vardecl list) = match l with
    [] -> []
    |(a::b) -> (name_of_vardecl a,i)::(list_vardecl (i+1) b);; 


let gen_instr  (f: 'a fundefn) = match f with
    Fundefn(Fundecl(_,_,params),varLocalList,stmt) -> 
        let varTab0= list_vardecl 0 params in 
            let varTab1 = varTab0@(list_vardecl (List.length varTab0) varLocalList) in 
                let var = IVarNum(List.length varTab1) in 
                   gen_stmt var stmt varTab1 ;;



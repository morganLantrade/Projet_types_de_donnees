#include <stdbool.h>
#include <stdio.h>

int testTyping (int n) {
  int x;
  x= 2;
  if (x == 0) {
    return (42); }
  else {
  x = x + 1; }

}



  
#load "lang.cmo";;
#load "typing.cmo";;
#load "instrs.cmo";;
#load "gen.cmo";;

open Lang;;
open Typing;;
open Instrs;;
open Gen;;



let test1= Fundefn (Fundecl (BoolT, "even", [Vardecl (IntT, "n")]), [],
 Seq
  (Seq
    (Cond
      (BinOp (BoolT, BCompar BClt, VarE (IntT, "n"), Const (IntT, IntV 0)),
      Assign (IntT, "n",
       BinOp (IntT, BArith BAsub, Const (IntT, IntV 0), VarE (IntT, "n"))),
      Skip),
    Assign (IntT, "n",
     BinOp (IntT, BArith BAsub, VarE (IntT, "n"), Const (IntT, IntV 2)))),
  Return
   (BinOp (BoolT, BCompar BCeq, VarE (IntT, "n"), Const (IntT, IntV 0)))));;

let test= gen_instr test1;; (
(* Compilation functions *)

open Lang
open Instrs

(* ************************************************************ *)
(* **** Compilation of expressions / statements            **** *)
(* ************************************************************ *)



let rec gen_expr (next : int ) (var: instr_var ) (exp : 'a expr)  = match exp with
     Const(_,BoolV(c)) -> let value = if c then 1 else 0 in 
                            [Store(var,ConstSE(value))]
    |Const(_,IntV(c)) -> [Store(var,ConstSE(c))]
    |VarE(_,name) -> [Store(var,VarSE(IVarNamed(name)))]
    |BinOp (_, b, e1,e2) -> 
        let var1,var2 = IVarNum(next),IVarNum(next+1) in
            let ex1,ex2 = gen_expr (next+1) var1 e1 , gen_expr (next+2) var2 e2  in 
                ex1@ex2@[Store(var,BinOpSE(b,var1,var2))]
    |IfThenElse (_,cond, e1,e2) -> 
        let var1,var2 = IVarNum(next),IVarNum(next+1) in
             let c,ex1,ex2 = gen_expr next var cond , gen_expr (next+1) var1 e1 , gen_expr (next+2) var2 e2 in 
                let lg = List.length ex1  in 
                    c@[Branch(var,RelJump(1),RelJump(lg+1))]@ex1@ex2;;




let rec gen_stmt  (stmt: 'a stmt)  = match stmt with 
    Skip -> [Goto(RelJump(1))]
   | Assign(_,name,exp) -> gen_expr 0 (IVarNamed(name)) exp
   | Seq(stmt1,stmt2) -> let s1,s2 = gen_stmt stmt1 , gen_stmt stmt2 in 
          s1@s2
   | While(exp,stmt) -> 
        let e1 = gen_expr 1 (IVarNum(0)) exp in 
            let s1=  gen_stmt stmt  in 
                let l1,l2 = List.length e1,List.length s1 in
                e1@[Branch((IVarNum(0)),RelJump(1),RelJump(l2+2))]@s1@[Goto(RelJump(-(l2+l1+1)))]
  | Cond(exp,stmt1,stmt2) ->
            let e1 = gen_expr 1 (IVarNum(0)) exp  in
                let s1,s2=  gen_stmt stmt1 , gen_stmt stmt2  in  
                    let l1= List.length s1 in
                e1@[Branch(IVarNum(0),RelJump(1),RelJump(l1+1))]@s1@s2


  | Return(exp) -> let e1 = gen_expr 1 (IVarNum(0)) exp  in 
                e1@[Exit((IVarNum(0)))];;


let gen_instr  (f: 'a fundefn) = match f with
    Fundefn(_,_,stmt) -> 
        gen_stmt stmt ;;


(* ************************************************************ *)
(* **** Initialisation Tableau des variables               **** *)
(* ************************************************************ *)
let name_of_vardecl (Vardecl (_, vn)) = vn;;

(*List asso IVarNamed : indice initialisée par parametres + variables locales*)
let rec list_vardecl (i : int) (l : vardecl list) = match l with
    [] -> []
    |(a::b) -> (IVarNamed(name_of_vardecl a),i)::(list_vardecl (i+1) b);; 


(*retourne l'indice le plus élevé d'une variable auxiliaire dans la liste d'instruction*)
let rec max_auxi (m:int) (instrTab: (rel_jump, instr_var) instr list)  = match instrTab with 
    [] -> m
    |(instr::lst) -> match instr with
        Store(IVarNum(i),_) -> let maxi= if i>m then i else m in max_auxi maxi lst
       |Branch(IVarNum(i),_,_) -> let maxi= if i>m then i else m in max_auxi maxi lst
       |Exit(IVarNum(i)) -> let maxi= if i>m then i else m in max_auxi maxi lst
       | _ -> max_auxi m lst;;

(* Retourne la liste d'association IVar_str : *)
let asso_varTab (f: 'a fundefn)  = match f with
    Fundefn(Fundecl(_,_,params),varLocalList,stmt) -> 
        let instrTab = gen_stmt stmt in 
            let varTab0= list_vardecl 0 params in 
                let varTab1 = varTab0@(list_vardecl (List.length varTab0) varLocalList) in 
                    let nb_var_named= (List.length varTab1) in
                        let nb_var_auxi = max_auxi 0 instrTab in 
                            varTab1@(List.init (nb_var_auxi+1) (fun x -> (IVarNum(x),x+nb_var_named)));;


let init_varTab (f: 'a fundefn) = 
    let varTab = Array.make (List.length (asso_varTab f)) 0 in 
        varTab;;
    
let rec init_params (varTab: int array) (i : int) = function 
    [] -> varTab
    |(param::lst) -> let _= Array.set varTab i  param in 
         init_params varTab (i+1) lst;;


(* ************************************************************ *)
(* **** Traduction de RelJump VarNamed to AbsJump IIndex   **** *)
(* ************************************************************ *)


(* Retourne une exp instr_var into IIndex *)
let trad1_exp  (e : 'instr_var simple_expr ) (asso : (instr_var * int) list ) = match e with 
    VarSE(v) -> let index= List.assoc v asso in 
                                VarSE(IIndex(index))
    |BinOpSE(b,v1,v2) -> let index1= List.assoc v1 asso in 
                    let index2= List.assoc v2 asso  in 
                BinOpSE(b,IIndex(index1),IIndex(index2))
    |ConstSE(c) -> ConstSE(c);;


(* Retourne la liste d'instruction IIndex , RelJump*)
let trad1 (f: 'a fundefn) = 
    let instrTab= gen_instr f in 
        let asso = asso_varTab f in 
            let g (instr : (rel_jump, instr_var) instr ) = match instr with 
                Store(v,a) -> let index= List.assoc v asso in 
                        let new_a = trad1_exp a asso in 
                    Store(IIndex(index),new_a)
               |Branch(v,j1,j2) -> let index= List.assoc v asso in 
                    Branch(IIndex(index),j1,j2)
               |Exit(v) -> let index= List.assoc v asso in 
                    Exit(IIndex(index))
               |Goto(a) -> Goto(a)  in 
                        
                    List.map g instrTab ;;

(* Retourne la liste d'instruction IIndex , AbsJump*)
let trad2 (instrTab: (rel_jump, instr_index) instr list) = 
    let g (pc:int) (instr : (rel_jump, instr_index) instr ) = match instr with 
                Branch(v,RelJump(j1),RelJump(j2)) -> Branch(v,AbsJump(j1+pc),AbsJump(j2+pc))
               |Goto(RelJump(j)) -> Goto(AbsJump(j+pc))
               |Exit(v)  -> Exit(v) 
               |Store(v,a) -> Store(v,a)  in 
                   Array.of_list (List.mapi g instrTab);;
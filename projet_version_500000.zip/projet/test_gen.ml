#load "lang.cmo";;
#load "typing.cmo";;
#load "instrs.cmo";;
#load "gen.cmo";;

open Lang;;
open Typing;;
open Instrs;;
open Gen;;



let test1=Fundefn (Fundecl (IntT, "fac", [Vardecl (IntT, "n")]),
 [Vardecl (IntT, "res")],
 Seq
  (Seq (Assign (0, "res", Const (0, IntV 1)),
    While (BinOp (0, BCompar BCgt, VarE (0, "n"), Const (0, IntV 1)),
     Seq
      (Assign (0, "res",
        BinOp (0, BArith BAmul, VarE (0, "res"), VarE (0, "n"))),
      Assign (0, "n",
       BinOp (0, BArith BAsub, VarE (0, "n"), Const (0, IntV 1)))))),
  Return (VarE (0, "res"))));;

let test2=Fundefn (Fundecl (BoolT, "even", [Vardecl (IntT, "n")]), [],
 Seq
  (Seq
    (Cond (BinOp (0, BCompar BClt, VarE (0, "n"), Const (0, IntV 0)),
      Assign (0, "n",
       BinOp (0, BArith BAsub, Const (0, IntV 0), VarE (0, "n"))),
      Skip),
    While (BinOp (0, BCompar BCgt, VarE (0, "n"), Const (0, IntV 1)),
     Assign (0, "n",
      BinOp (0, BArith BAsub, VarE (0, "n"), Const (0, IntV 2))))),
  Return (BinOp (0, BCompar BCeq, VarE (0, "n"), Const (0, IntV 0)))));;



let traduct1=trad1 test1;;
let varInstr1 = trad2 traduct1;;
let varTab1= init_varTab test1;;
let varTab_i_1=init_params varTab1 0 [5];;
let test_exec1 = run_code varInstr1 varTab_i_1 0;;

let traduct2=trad1 test2;;
let varInstr2 = trad2 traduct2;;
let varTab2= init_varTab test2;;
let varTab_i_2=init_params varTab2 0 [4];;
let test_exec2 = run_code varInstr2 varTab_i_2 0;;
